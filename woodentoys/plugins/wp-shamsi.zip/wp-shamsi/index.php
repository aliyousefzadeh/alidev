<?php

/**
 * @package WPSH
 */

// Silence is Golden
// $variable
